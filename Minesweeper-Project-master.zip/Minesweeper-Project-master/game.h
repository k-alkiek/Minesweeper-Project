#ifndef GAMEHEADER
#define GAMEHEADER

bool inRange();
bool validAction(char input);
void clearScreen(void);
bool play();
bool startup();



#endif
