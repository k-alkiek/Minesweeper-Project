#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "cells.h"
#include "game.h"





int main(void){

    if (startup() )
        return 0;

    return 0;
}

